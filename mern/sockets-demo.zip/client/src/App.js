import React from 'react';
import logo from './logo.svg';
import './App.css';
import Bidding from './components/Bidding';

function App() {
  return (
    <div className="App">
      <Bidding/>
    </div>
  );
}

export default App;
