import React, { useEffect, useState } from 'react';
import io from 'socket.io-client';

export default function Bidding() {
  const [socket] = useState(() => io(':8000'));
  const [currentPrice, setCurrentPrice] = useState(null);
  const [history, setHistory] = useState([]);
  const [myBid, setMyBid] = useState(null);

  useEffect(() => {
    socket.on('new user', console.log);

    socket.on('new user arrived', console.log);

    socket.on('details', data => {
      setMyBid(data.currentPrice + 1);
      setCurrentPrice(data.currentPrice);
      setHistory(data.history);
    });

    socket.on('new bid received', data => {
      setCurrentPrice(data.amount);
      setMyBid(data.amount + 1);
      setHistory(currentHistory => [...currentHistory, data]);
    });

    return () => socket.disconnect();
  }, []);

  function handleSubmit(event) {
    event.preventDefault();

    if(myBid <= currentPrice) return;

    socket.emit('make new bid', myBid);
  }

  if(currentPrice === null) return 'Loading...';

  return (
    <div>
      <p>Current Price: {currentPrice}</p>
      <p>History:</p>
      <ul>
        {history.map((bid, idx) => (
          <li key={idx}>Someone bid {bid.amount} at {bid.timestamp.toLocaleString()}.</li>
        ))}
      </ul>
      <form onSubmit={handleSubmit}>
        <input
          value={myBid}
          onChange={e => setMyBid(+e.target.value)}
        />
        <button>Submit Bid!</button>
      </form>
    </div>
  )
}